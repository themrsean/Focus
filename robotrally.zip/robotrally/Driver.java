/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally;

import robotrally.mapcells.*;
import robotrally.robot.Robot;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Main driver class for Robot Rally. Used for testing.
 */
public class Driver {
    private static final int DEFAULT_WIDTH = 12;
    private static final int DEFAULT_HEIGHT = 16;
    private static final int FOUR_SECONDS = 4000;
    private static Map map;
    private static int numFlags;

    public static void main(String[] args) {
        // Generate map
        map = new Map(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        map.initialize();
        int selection = selectMap();
        if (!loadMap(selection)) {
            System.err.println("Could not load map. Exiting.");
            System.exit(0);
        }

        // Add robot
        Robot robot = new Robot(map.getDock(1), numFlags);
        System.out.println(map);
        System.out.println(robot);

        testGame(robot);
    }

    /**
     * Helper method to select the map to use
     * @return The corresponding map number chosen
     */
    private static int selectMap() {
        boolean valid = false;
        int map = -1;
        while (!valid) {
            Scanner in = new Scanner(System.in);
            displayMenu();
            try {
                map = in.nextInt();
                if (map >= 0 && map <= 1) {
                    valid = true;
                }
            } catch (InputMismatchException e) {
                System.err.println("Please enter a number between 0-1.");
            }
        }
        return map;
    }

    /**
     * A helper method to display the menu for selecting a map
     */
    private static void displayMenu() {
        System.out.println("Select map:");
        System.out.println("1. Risky Exchange");
        System.out.println("0. Quit");
        System.out.print("Enter choice (0-1): ");
    }

    /**
     * A helper method that loads the map file into memory and calls the readFile() method to
     * read the data
     * @param selection The map selection
     * @return True if the map is loaded successfully. False otherwise.
     */
    private static boolean loadMap(int selection) {
        File file = null;
        switch (selection) {
            case 0:
                System.out.println("Buh-bye");
                System.exit(0);
            case 1:
                file = new File("risky_exchange.txt");
                break;
        }
        return readFile(file);
    }

    /**
     * A helper method to read the map file chosen.
     * @param file The map file
     * @return true if successfully read, false otherwise
     */
    private static boolean readFile(File file) {
        try {
            Scanner read = new Scanner(file);
            numFlags = read.nextInt();
            read.nextLine();
            while (read.hasNextLine()) {
                MapCell cell = parseCell(read.nextLine());
                map.addCell(cell, cell.getX(), cell.getY());
            }
            map.setLasers();

        } catch (FileNotFoundException e) {
            System.err.println("Error. Could not find file");
            return false;
        }
        return true;
    }

    /**
     * A helper method to parse the data read from the map file and create individual cells in the
     * map from the information read.
     * @param line A single line read from the map file
     * @return The MapCell object generated from the data
     */
    private static MapCell parseCell(String line) {
        /*
         * x,y,type,N,S,E,W,SPECIAL
         * C -  Conveyor Belt - direction
         * EC - Express Conveyor Belt - direction
         * EM - Empty Cell
         * D -  Dock
         * F -  Flag
         * G -  Gear - rotation
         * L -  Laser - direction
         * P -  Pit
         * RP - Repair
         */
        MapCell cell;
        String[] split = line.split(",");
        // xy coordinates
        int x = Integer.parseInt(split[0]);
        int y = Integer.parseInt(split[1]);
        String type = split[2];

        switch (type) {
            case "C":
                Direction d = parseDirection(split[7]);
                cell = new ConveyorBelt(d);
                break;
            case "EC":
                d = parseDirection(split[7]);
                cell = new ExpressConveyorBelt(d);
                break;
            case "D":
                int robot = Integer.parseInt(split[7]);
                cell = new Dock(robot);
                break;
            case "F":
                int number = Integer.parseInt((split[7]));
                cell = new Flag(number);
                break;
            case "G":
                Rotation rotate = parseRotation(split[7]);
                cell = new Gear(rotate);
                break;
            case "L":
                d = parseDirection(split[7]);
                cell = new Laser(d);
                break;
            case "P":
                cell = new Pit();
                break;
            case "RP":
                cell = new Repair();
                break;
            default:
                cell = new EmptyCell();
        }

        cell.setX(x);
        cell.setY(y);

        if (split[3].equals("Y")) {
            cell.setNorthWall(true);
        }
        if (split[4].equals("Y")) {
            cell.setSouthWall(true);
        }
        if (split[5].equals("Y")) {
            cell.setEastWall(true);
        }
        if (split[6].equals("Y")) {
            cell.setWestWall(true);
        }
        return cell;
    }

    /**
     * A helper method that parses a given String into a Direction
     * @param d A String corresponding to a Direction
     * @return the Direction object created
     */
    private static Direction parseDirection(String d) {
        switch (d) {
            case "N":
                return Direction.NORTH;
            case "S":
                return Direction.SOUTH;
            case "E":
                return Direction.EAST;
            default:
                return Direction.WEST;
        }
    }

    /**
     * A helper method that parses a given String into a Rotation
     * @param r A String corresponding to a Rotation
     * @return the Rotation object created
     */
    private static Rotation parseRotation(String r) {
        if (r.equals("L")) {
            return Rotation.LEFT;
        } else {
            return Rotation.RIGHT;
        }
    }

    /**
     * This method moves the robot in the direction it is facing and updates the map, accordingly
     *
     * @param robot The robot being moved
     */
    public static void move(Robot robot) {
        // TODO!!!!!
        // Find the current location of the robot

        // Find which way the robot is currently facing

        // Check to see if the way forward has a wall or not

            // If the way is clear, move the robot to the appropriate MapCell
            // First, calculate the new x and y values

            // Make sure the new values are valid and exist in the map

                // If they are, update the robot's location for both the Map and the Robot

                // If they are not, the Robot ran off the edge of the map and has died,
                // Report this using System.err.println() and update accordingly.

            // If the way is blocked, report this using System.err.println()

    }

    /**
     * A testing method that checks to make sure all of the different parts of the map
     * are functioning
     * @param robot The robot to test with
     */
    private static void testGame(Robot robot) {
        System.out.println("Testing first flag...");
        String[] robotPlan1 = {"M", "M", "M", "RR", "M", "RL", "M", "M", "W", "W",
                "W", "M", "M", "W", "RR", "M"};
        int moves = 0;
        while (moves < robotPlan1.length) {
            System.out.println(map);
            System.out.println(robot);
            String move = robotPlan1[moves];
            runPlan(robot, move);
            ++moves;
            map.update(robot);
        }
        if (robot.flagsFound() != 1) {
            error(robot, 1);
        }

        System.out.println("Testing second flag...");
        String[] robotPlan2 = {"M", "RR", "W", "M", "M", "M"};
        moves = 0;
        while (moves < robotPlan2.length) {
            System.out.println(map);
            System.out.println(robot);
            String move = robotPlan2[moves];
            runPlan(robot, move);
            ++moves;
            map.update(robot);
        }
        if (robot.flagsFound() != 2) {
            error(robot, 2);
        }

        System.out.println("Testing third flag...");
        String[] robotPlan3 = {"M", "RL", "M", "RL", "M", "RR", "M", "M", "M", "M", "RR", "M",
                "RR", "M", "RL", "M", "RR", "RR", "M", "RL", "M", "M", "M"};
        moves = 0;
        while (moves < robotPlan3.length) {
            System.out.println(map);
            System.out.println(robot);
            String move = robotPlan3[moves];
            runPlan(robot, move);
            ++moves;
            map.update(robot);
        }
        System.out.println(map);
        System.out.println(robot);
        if (robot.flagsFound() != 3) {
            error(robot, 3);
        }

        moves = 0;

        System.out.println("Testing hazards...");
        robot.setLocation(robot.getDock());
        System.out.println(map);
        System.out.println(robot);
        // Test wall
        String[] hazards1 = {"RR", "M"};
        while (moves < hazards1.length) {
            System.out.println(map);
            System.out.println(robot);
            String move = hazards1[moves];
            runPlan(robot, move);
            ++moves;
            map.update(robot);
        }
        if(!robot.getLocation().equals(robot.getDock())) {
            System.out.println("Wall test failed.");
        }

        // test falling off edge
        moves = 0;
        while (moves < hazards1.length) {
            System.out.println(map);
            System.out.println(robot);
            String move = hazards1[moves];
            runPlan(robot, move);
            ++moves;
            map.update(robot);
        }
        if(robot.getLives() != 2 || !robot.getLocation().equals(robot.getDock())) {
            System.out.println("Falling off edge test failed.");
        }

        // Test pit
        robot.setFacing(Direction.NORTH);
        String[] hazards2 = {"M", "M", "RL", "M", "M", "M", "RR", "M", "RL", "M", "RR",
                "M", "RL", "M", "RR", "M"};
        moves = 0;
        while (moves < hazards2.length) {
            System.out.println(map);
            System.out.println(robot);
            String move = hazards2[moves];
            runPlan(robot, move);
            ++moves;
            map.update(robot);
        }
        if(robot.getLives() != 1 || !robot.getLocation().equals(robot.getDock())) {
            System.out.println("Pit test failed.");
        }

        // Test lasers
        robot.setFacing(Direction.NORTH);
        String[] hazards3 = {"M", "M", "M", "RR", "M", "RL", "M", "M", "M", "M", "RR", "M",
                "RL", "M", "W", "M", "M", "M", "RL", "M", "M", "RR", "M"};
        moves = 0;
        while (moves < hazards3.length) {
            System.out.println(map);
            System.out.println(robot);
            String move = hazards3[moves];
            runPlan(robot, move);
            ++moves;
            map.update(robot);
        }
        if(robot.getDamagePoints() != 6) {
            System.out.println("Laser test failed");
        }

        System.out.println("All tests complete.");
        System.out.println(map);
        System.out.println(robot);
    }

    /**
     * A helper method that pauses for a set time to allow the user to read the map, then
     * runs the given move and updates the game state
     * @param robot The robot being moved
     * @param move The move selection for the current action
     */
    private static void runPlan(Robot robot, String move) {
        try {
            Thread.sleep(FOUR_SECONDS);
            executeAction(robot, move);
            map.activate(robot);
            checkExpressConveyor(robot);
            map.checkpoints(robot);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * A helper method that executes the action passed into the plan
     * @param robot The robot performing the action
     * @param move The action
     */
    private static void executeAction(Robot robot, String move) {
        switch (move) {
            case "M":
                move(robot);
                break;
            case "RR":
                robot.turnRight();
                break;
            case "RL":
                robot.turnLeft();
                break;
            default:
                // Waiting. No action performed
        }
    }

    /**
     * A helper method that checks if the robot is on an Express Conveyor, which would
     * move the robot a second time
     * @param robot The robot being used
     */
    private static void checkExpressConveyor(Robot robot) {
        if (robot.getLocation() instanceof ExpressConveyorBelt) {
            robot.getLocation().activate(robot);
        }
    }

    /**
     * Helper method that reports an error if the flags are not retrieved properly
     * @param robot The robot being used
     * @param flags The number of flags expected
     */
    private static void error(Robot robot, int flags) {
        System.err.println("Should now have" + flags + " flags, but you have " +
                robot.flagsFound() + ". Check your code and try again.");
        System.exit(0);
    }
}
