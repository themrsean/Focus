/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.robot.Robot;

/**
 * An abstract MapCell. The activate() method must be overridden by any inheriting class
 */
public abstract class MapCell implements Comparable<MapCell> {
    private static final int DEFAULT_PRIORITY = 100;

    protected int x = 0;
    protected int y = 0;
    protected boolean northWall = false;
    protected boolean southWall = false;
    protected boolean eastWall = false;
    protected boolean westWall = false;
    protected boolean occupied = false;
    protected boolean laser = false;
    protected int priority;

    /**
     * Constructor for a MapCell
     */
    public MapCell() {
        this.priority = DEFAULT_PRIORITY;
    }

    /**
     * Constructor for a MapCell with a specific location
     * @param x x-coordinate of the MapCell
     * @param y y-coordinate of the MapCell
     */
    public MapCell(int x, int y) {
        this.priority = DEFAULT_PRIORITY;
        this.x = x;
        this.y = y;
    }

    public int getPriority() {
        return this.priority;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setNorthWall(boolean northWall) {
        this.northWall = northWall;
    }

    public void setSouthWall(boolean southWall) {
        this.southWall = southWall;
    }

    public void setEastWall(boolean eastWall) {
        this.eastWall = eastWall;
    }

    public void setWestWall(boolean westWall) {
        this.westWall = westWall;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    public void setLaser(boolean laser) {
        this.laser = laser;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    /**
     * Returns true if a given direction is blocked by a wall, false otherwise
     * @param facing The direction to check for a wall
     * @return True if a wall is blocking the way, false otherwise
     */
    public boolean isBlocked(Direction facing) {
        switch(facing) {
            case NORTH:
                return northWall;
            case SOUTH:
                return southWall;
            case EAST:
                return eastWall;
            default:
                return westWall;
        }
    }

    /**
     * Abstract method that defines what occurs when the robot ends its turn on this cell
     * @param robot The robot being affected by the cell
     */
    public abstract void activate(Robot robot);


    /**
     * An Overridden method that generates a String representation of the MapCell.
     * @return A String representation of the MapCell.
     */
    @Override
    public String toString() {
        return "--";
    }

    /**
     * Method that compares this MapCell to another MapCell, based on their priority level.
     * Used to put cells in order before activating them
     * @param o The other MapCell being compared
     * @return A positive number if the priority of this MapCell is higher,
     * zero if the priority is the same,
     * a negative number of the priority is less
     */
    public int compareTo(MapCell o) {
        return this.priority - o.priority;
    }
}
