/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.robot.Robot;

@SuppressWarnings("ALL")
/**
 * A Pit is instant death for a Robot
 */
public class Pit extends MapCell {
    public static final String ANSI_RED = "\u001B[31m";
    private static final int DEFAULT_PRIORITY = 5;

    /**
     * Constructor for a Pit
     */
    public Pit() {
        this.priority = DEFAULT_PRIORITY;
    }

    /**
     * When this cell is activated, the robot dies and is returned to its dock
     * @param robot The unfortunate robot
     */
    public void activate(Robot robot) {
        System.err.println("Robot fell into a pit!");
        robot.removeLife();
        robot.setLocation(robot.getDock());
    }

    @Override
    /**
     * An Overridden method that generates a String representation of the Pit.
     * @return A String representation of the Pit.
     */
    public String toString() {
        return ANSI_RED + "PT";
    }
}
