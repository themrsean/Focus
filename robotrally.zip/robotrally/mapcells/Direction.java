/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

/**
 * An enumeration of the four cardinal directions and their relationships to each other
 * and to the Map
 */
public enum Direction {
    NORTH(0, -1, "N"),
    SOUTH(0, 1, "S"),
    EAST(1, 0, "E"),
    WEST(-1, 0, "W");

    private int xDelta;
    private int yDelta;
    private String dir;
    private Direction opposite;
    private Direction left;
    private Direction right;

    static {
        NORTH.opposite = SOUTH;
        NORTH.left = WEST;
        NORTH.right = EAST;
        SOUTH.opposite = NORTH;
        SOUTH.left = EAST;
        SOUTH.right = WEST;
        EAST.opposite = WEST;
        EAST.left = NORTH;
        EAST.right = SOUTH;
        WEST.opposite = EAST;
        WEST.left = SOUTH;
        WEST.right = NORTH;
    }

    /**
     * Constructor for the Direction enum
     * @param x The change in x when moving in this direction
     * @param y The change in y when moving in this direction
     * @param dir String representation of this direction
     */
    Direction(int x, int y, String dir) {
        xDelta = x;
        yDelta = y;
        this.dir = dir;

    }

    public int getxDelta() {
        return xDelta;
    }

    public int getyDelta() {
        return yDelta;
    }

    public Direction getOpposite() {
        return opposite;
    }

    public Direction getLeft() {
        return left;
    }

    public Direction getRight() {
        return right;
    }

    /**
     * An Overridden method that generates a String representation of the Direction.
     * @return A String representation of the Direction.
     */
    @Override
    public String toString() {
        return dir;
    }
}
