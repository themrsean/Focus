/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.robot.Robot;

/**
 * The Gear rotates a robot clockwise or counterclockwise, based on its Rotation
 */
public class Gear extends MapCell {
    private static final int DEFAULT_PRIORITY = 4;
    private final Rotation rotation;

    /**
     * Constructor for the Gear
     * @param rotation The rotation of the gear, left for counterclockwise, right for clockwise
     */
    public Gear(Rotation rotation) {
        this.rotation = rotation;
        this.priority = DEFAULT_PRIORITY;
    }

    /**
     * When the cell is activated, the robot is turned 90 degrees in the given direction
     * @param robot The robot being rotated
     */
    public void activate(Robot robot) {
        if(rotation == Rotation.LEFT) {
            robot.setFacing(robot.getFacing().getLeft());
        } else {
            robot.setFacing(robot.getFacing().getRight());
        }
    }

    /**
     * An Overridden method that generates a String representation of the Gear.
     * @return A String representation of the Gear.
     */
    @Override
    public String toString() {
        return "G" + rotation;
    }
}
