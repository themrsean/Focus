/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.robot.Robot;

/**
 * The Laser shoots a beam from one laser wall to another, causing 1 point of damage to any
 * robot that crosses the beam.
 */
public class Laser extends MapCell {
    private static final String ANSI_RED = "\u001B[31m";
    private static final int DEFAULT_PRIORITY = 6;
    private final Direction direction;

    /**
     * Constructor for the Laser
     * @param direction The direction the laser is being shot
     */
    public Laser(Direction direction) {
        this.priority = DEFAULT_PRIORITY;
        this.direction = direction;
        setLaser(true);
        setWall(direction.getOpposite());
    }

    public Direction getDirection() {
        return this.direction;
    }

    /**
     * When the cell is activated, any robot in this cell will take 1 point
     * of damage
     * @param robot the robot being damaged
     */
    public void activate(Robot robot) {
        System.err.println("Robot takes laser damage!");
        robot.takeDamage();
    }

    /**
     * Sets the wall that the laser is emanating from
     * @param direction The direction the laser is shooting
     */
    private void setWall(Direction direction) {
        switch(direction.toString()) {
            case "N":
                setNorthWall(true);
                break;
            case "S":
                setSouthWall(true);
                break;
            case "E":
                setEastWall(true);
                break;
            case "W":
                setWestWall(true);
        }
    }



    /**
     * An Overridden method that generates a String representation of the Laser.
     * @return A String representation of the Laser.
     */
    @Override
    public String toString() {
        return ANSI_RED + "L" + direction;
    }


}
