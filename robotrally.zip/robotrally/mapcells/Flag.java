/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.robot.Robot;

/**
 * A Flag is the objective of the Robot. Each flag has a unique number.
 */
public class Flag extends MapCell {
    private static final String ANSI_PURPLE = "\u001B[35m";
    private static final int DEFAULT_PRIORITY = 7;
    private final int number;

    /**
     * Constructor for the Flag
     * @param number The unique flag number
     */
    public Flag(int number) {
        this.priority = DEFAULT_PRIORITY;
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    /**
     * When the cell is activated, the robot is updated to reflect having found
     * this specific flag. Repeatedly finding the same flag has no effect
     * @param robot The robot that found the flag
     */
    public void activate(Robot robot) {
        robot.setFlag(number);
    }


    /**
     * An Overridden method that generates a String representation of the Flag.
     * @return A String representation of the Flag.
     */
    @Override
    public String toString() {
        return ANSI_PURPLE + "F" + number;
    }
}
