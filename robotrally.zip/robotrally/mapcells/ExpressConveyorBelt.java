/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

/**
 * An Express Conveyor Belt that moves the Robot two cells in a given direction
 */
public class ExpressConveyorBelt extends ConveyorBelt {
    private static final int DEFAULT_PRIORITY = 1;

    /**
     * Constructor for the Express Conveyor Belt
     * @param direction The direction of the Belt
     */
    public ExpressConveyorBelt(Direction direction) {
        super(direction);
        this.priority = DEFAULT_PRIORITY;
    }


    /**
     * An Overridden method that generates a String representation of the Express Conveyor Belt.
     * @return A String representation of the Express Conveyor Belt.
     */
    @Override
    public String toString() {
        return "E" + direction;
    }
}
