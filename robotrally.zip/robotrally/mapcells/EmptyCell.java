/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.robot.Robot;

/**
 * An Empty Cell. Not all cells are interesting.
 */
public class EmptyCell extends MapCell {
    /**
     * Constructor for the Empty Cell
     */
    public EmptyCell() {
        super();
    }

    /**
     * Constructor for the Empty Cell with a specific location
     * @param x x-coordinate of the Empty Cell
     * @param y y-coordinate of the Empty Cell
     */
    public EmptyCell(int x, int y) {
        super(x, y);
    }

    /**
     * When the cell is activated, nothing happens...
     * @param robot The robot nothing is happening to
     */
    @Override
    public void activate(Robot robot) {
        // Empty cell. Nothing happens on activation.
    }
}
