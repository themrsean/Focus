/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.robot.Robot;

/**
 * A Repair cell heals a robot 1 damage point
 */
public class Repair extends MapCell {
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final int DEFAULT_PRIORITY = 10;

    /**
     * Constructor for a Repair cell
     */
    public Repair() {
        this.priority = DEFAULT_PRIORITY;
    }

    /**
     * When this cell activates, it heals the robot 1 damage point
     * @param robot The robot being healed
     */
    public void activate(Robot robot) {
        robot.repair();
    }

    /**
     * An Overridden method that generates a String representation of the Repair.
     * @return A String representation of the Repair.
     */
    @Override
    public String toString() {
        return ANSI_GREEN + "RP";
    }
}
