/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;


/**
 * A Dock that is both the starting location of a Robot and that can repair the Robot
 */
@SuppressWarnings("WeakerAccess")
public class Dock extends Repair {
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final int DEFAULT_PRIORITY = 10;
    private final int robotNumber;

    /**
     * Constructor for the Dock
     * @param robot The robot that will spawn at this dock
     */
    public Dock(int robot) {
        this.priority = DEFAULT_PRIORITY;
        this.robotNumber = robot;
    }

    public int getRobotNumber() {
        return robotNumber;
    }


    /**
     * An Overridden method that generates a String representation of the Dock.
     * @return A String representation of the Dock.
     */
    @Override
    public String toString() {
        return ANSI_GREEN + "D" + robotNumber;
    }
}
