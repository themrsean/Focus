/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

/**
 * A Rotation enumeration that defines Left and Right (counterclockwise and clockwise) rotations
 */
public enum Rotation {
    RIGHT("R"), LEFT("L");

    private final String dir;

    /**
     * Constructor for the Rotation
     * @param dir The String representation of the Rotation
     */
    Rotation(String dir) {
        this.dir = dir;
    }

    /**
     * An Overridden method that generates a String representation of the Rotation.
     * @return A String representation of the Rotation.
     */
    @Override
    public String toString() {
        return dir;
    }
}
