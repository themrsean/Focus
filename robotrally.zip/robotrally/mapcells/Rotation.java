package robotrally.mapcells;

public enum Rotation {
    RIGHT, LEFT
}
