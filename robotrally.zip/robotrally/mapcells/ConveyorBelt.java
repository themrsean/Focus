package robotrally.mapcells;

import javafx.scene.paint.Color;
import robotrally.Controller;
import robotrally.robot.Robot;

@SuppressWarnings("ALL")
public class ConveyorBelt extends MapCell {
    private static final int DEFAULT_PRIORITY = 2;
    protected final Direction direction;
    protected Controller controller;

    public ConveyorBelt(Direction direction) {
        this.priority = DEFAULT_PRIORITY;
        this.direction = direction;
        this.color = Color.LIGHTBLUE;
    }

    public Direction getDirection() {
        return this.direction;
    }

    public void setController(Controller controller) {
        this.controller = controller;
    }

    public void activate(Robot robot) {
        Direction facing = robot.getFacing();
        robot.setFacing(direction);
        controller.move();
        robot.setFacing(facing);
    }
}
