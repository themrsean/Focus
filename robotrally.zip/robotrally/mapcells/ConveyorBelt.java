/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.mapcells;

import robotrally.Driver;
import robotrally.robot.Robot;


/**
 * A Conveyor Belt that moves the robot one space in a given direction
 */
@SuppressWarnings("WeakerAccess")
public class ConveyorBelt extends MapCell {
    private static final int DEFAULT_PRIORITY = 2;
    protected final Direction direction;

    /**
     * Constructor for the Conveyor Belt
     * @param direction Direction of the Conveyor Belt
     */
    public ConveyorBelt(Direction direction) {
        this.priority = DEFAULT_PRIORITY;
        this.direction = direction;
    }

    /**
     * When the cell is activated, the robot is moved one cell in the direction the
     * Conveyor Belt is moving
     * @param robot The robot being moved
     */
    public void activate(Robot robot) {
        Direction facing = robot.getFacing();
        robot.setFacing(direction);
        Driver.move(robot);
        robot.setFacing(facing);
    }

    /**
     * An Overridden method that generates a String representation of the Conveyor Belt.
     * @return A String representation of the Conveyor Belt.
     */
    @Override
    public String toString() {
        return "C" + direction;
    }
}
