/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally.robot;

import robotrally.mapcells.Direction;
import robotrally.mapcells.Dock;
import robotrally.mapcells.MapCell;

/**
 * A Robot that is putting around a board full of obstacles
 */
@SuppressWarnings({"StringConcatenationInsideStringBufferAppend",
        "StringBufferReplaceableByString"})
public class Robot {
    private static final int STARTING_LIVES = 3;
    private static final int MAX_DAMAGE_POINTS = 10;
    private static final Direction STARTING_FACING = Direction.NORTH;

    private int lives;
    private int damagePoints;
    private final Dock dock;
    private Direction facing;
    private MapCell location;
    private final boolean[] flags;

    /**
     * Constructor for the Robot
     * @param dock The starting Dock cell. The Robot will always respawn at this point
     * @param numFlags The number of flags needed to be found
     */
    public Robot(Dock dock, int numFlags) {
        this.lives = STARTING_LIVES;
        this.damagePoints = MAX_DAMAGE_POINTS;
        this.dock = dock;
        this.location = dock;
        dock.setOccupied(true);
        facing = STARTING_FACING;
        flags = new boolean[numFlags];
    }

    // Getters and Setters
    public int getLives() {
        return lives;
    }

    public int getDamagePoints() {
        return damagePoints;
    }

    public MapCell getDock() {
        return dock;
    }

    public Direction getFacing() {
        return facing;
    }

    public MapCell getLocation() {
        return location;
    }

    public void setFacing(Direction facing) {
        this.facing = facing;
    }

    public void setLocation(MapCell location) {
        this.location = location;
    }

    // Actions

    /**
     * Turns the robot 90 degrees to the left
     */
    public void turnLeft() {
        facing = facing.getLeft();
    }

    /**
     * Turns the robot 90 degrees to the right
     */
    public void turnRight() {
        facing = facing.getRight();
    }

    /**
     * Sets a boolean flag corresponding to the flag discovered
     * @param flagNumber The number of the flag
     */
    public void setFlag(int flagNumber) {
        flags[flagNumber - 1] = true;
    }

    /**
     * Repairs the robot by one damage point
     */
    public void repair() {
        if(damagePoints < MAX_DAMAGE_POINTS) {
            ++damagePoints;
        }
    }

    /**
     * Gives the robot one point of damage
     */
    public void takeDamage() {
        --damagePoints;
    }

    /**
     * Removes a life when a robot is destroyed
     */
    public void removeLife() {
        --lives;
    }

    /**
     * Returns the total number of flags currently found by the robot
     * @return The number of flags found
     */
    public int flagsFound() {
        int total = 0;
        for(boolean found : flags) {
            if(found) {
                ++total;
            }
        }
        return total;
    }


    /**
     * An Overridden method that generates a String representation of the Robot.
     * @return A String representation of the Robot.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Robot " + dock.getRobotNumber() + "\n=======\n");
        sb.append("Lives: " + lives + "\n");
        sb.append("Damage: " + damagePoints + "\n");
        sb.append("Location: " + location.getX() + ", " + location.getY() + "\n");
        sb.append("Facing: " + facing + "\n");
        sb.append("Flags taken: " + flagsFound());
        return sb.toString();
    }
}
