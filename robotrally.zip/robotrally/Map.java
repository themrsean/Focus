/*
 * Course: CS1021 - 001
 * Fall 2015
 * Lab 5 - Robot Rally
 * Name: Sean Jones
 * Created: 7/12/19
 */
package robotrally;

import robotrally.mapcells.Direction;
import robotrally.mapcells.Dock;
import robotrally.mapcells.EmptyCell;
import robotrally.mapcells.Flag;
import robotrally.mapcells.Laser;
import robotrally.mapcells.MapCell;
import robotrally.robot.Robot;

import java.util.Arrays;
import java.util.PriorityQueue;

/**
 * A Map containing a specific setup of the game. This map is generated using a text file
 */
@SuppressWarnings("StringConcatenationInsideStringBufferAppend")
public class Map {
    private static final String ANSI_BLACK = "\u001B[30m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_BLUE = "\u001B[34m";
    private static final int DOUBLE_DIGIT = 10;

    private final MapCell[][] cells;
    private final int width;
    private final int height;

    /**
     * Constructor for the Map class
     * @param width The number of cells wide the map is
     * @param height The number of cells tall the map is
     */
    public Map(int width, int height) {
        this.width = width;
        this.height = height;
        cells = new MapCell[height][width];
    }

    /**
     * Adds a cell to the map at the given x, y location if the location is valid.
     * Invalid locations are ignored and the cell is not added.
     *
     * @param cell The cell being added to the map
     * @param width The x coordinate of the cell
     * @param height The y coordinate of the cell
     */
    public void addCell(MapCell cell, int width, int height) {
        if(isOnMap(width, height)) {
            cells[height][width] = cell;
        }
    }

    /**
     * Initializes the map and fills it with all Empty Cells.
     */
    public void initialize() {
        for (int x = 0; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
                cells[y][x] = new EmptyCell(x, y);
            }
        }
    }

    /**
     * Returns the cell located att he given coordinates
     * @param width The x coordinate of the cell
     * @param height The y coordinate of the cel
     * @return The cell located at the given coordinates
     */
    public MapCell getCell(int width, int height) {
        return cells[height][width];
    }

    /**
     * Returns the location of the Dock with the given number
     * @param number The number of the Dock to return
     * @return The Dock with the corresponding number
     */
    public Dock getDock(int number) {
        for(MapCell[] row : cells) {
            for(MapCell m : row) {
                if(m instanceof Dock) {
                    if(((Dock) m).getRobotNumber() == number) {
                        return (Dock) m;
                    }
                }
            }
        }
        return null;
    }

    /**
     * A helper method that adds lasers to the appropriate cells.
     */
    public void setLasers() {
        for(MapCell[] row : cells) {
            for (MapCell m : row) {
                if (m instanceof Laser) {
                    MapCell current = m;
                    Direction laserPointing = ((Laser) m).getDirection();
                    int x = current.getX() + laserPointing.getxDelta();
                    int y = current.getY() + laserPointing.getyDelta();
                    while(isOnMap(x, y) && !(current instanceof Laser &&
                            ((Laser)current).getDirection().getOpposite().equals(laserPointing))) {
                        current = getCell(x, y);
                        current.setLaser(true);
                        x = current.getX() + laserPointing.getxDelta();
                        y = current.getY() + laserPointing.getyDelta();
                    }
                }
            }
        }
    }

    /**
     * A helper method that will return true if the coordinates entered exist in the map,
     * false otherwise
     * @param x x-coordinate to verify
     * @param y y-coordinate to verify
     * @return True if the x,y coordinates exist in the Map, false otherwise
     */
    public boolean isOnMap(int x, int y) {
        // TODO!!!!!!
    }

    /**
     * A helper method that updates the map with the current location of the robot
     * @param robot The robot
     */
    public void update(Robot robot) {
        MapCell current = robot.getLocation();
        for(MapCell[] row : cells) {
            for (MapCell m : row) {
                m.setOccupied(m.equals(current));
            }
        }
    }

    /**
     * This method activates all of the cells on the map. The cells are put into a
     * PriorityQueue and are executed in order of their priority, from low to high.
     * Cells with the same priority may only have a single cell activated at any
     * time.
     *
     * @param robot The robot on the map.
     */
    public void activate(Robot robot) {
        PriorityQueue<MapCell> activationList = new PriorityQueue<>();
        for(MapCell[] row : cells) {
            activationList.addAll(Arrays.asList(row));
        }
        int priority = Integer.MAX_VALUE;
        while(!activationList.isEmpty()) {
            MapCell current = activationList.poll();
            if(current.isOccupied()) {
                if(current.getPriority() != priority) {
                    current.activate(robot);
                    priority = current.getPriority();
                }
            }
        }
    }

    /**
     * A helper method that sets the flags discovered by a given robot
     * @param robot The robot discovering a flag.
     */
    public void checkpoints(Robot robot) {
        for(MapCell[] row : cells) {
            for(MapCell m : row) {
                if(m.isOccupied() && m instanceof Flag) {
                    int flagNumber = ((Flag) m).getNumber();
                    robot.setFlag(flagNumber);
                }
            }
        }
    }

    /**
     * An Overridden method that generates a String representation of the Map.
     * @return A String representation of the Map.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        // X-coordinate values
        sb.append("       ");
        for(int i = 0; i < width; ++i) {
            if(i < DOUBLE_DIGIT) {
                sb.append(i + "      ");
            } else {
                sb.append(i + "     ");
            }
        }
        sb.append("\n");

        // top border
        sb.append("    ");
        for (int i = 0; i < width; ++i) {
            sb.append("+------");
        }
        sb.append("+\n");

        // robotrally.Map rows
        for(int y = 0; y < height; ++y) {
            // Check for north wall
            sb.append("    |");
            for(int x = 0; x < width; ++x) {
                if(cells[y][x].isBlocked(Direction.NORTH)) {
                    sb.append(ANSI_RED + "  __  " + ANSI_BLACK);
                } else {
                    sb.append("      ");
                }
                if(x < width - 1) {
                    sb.append(" ");
                }
            }
            sb.append("|\n");
            // Row numbers
            if(y < DOUBLE_DIGIT) {
                sb.append(" " + y + "  |");
            } else {
                sb.append(y + "  |");
            }

            // Add cells
            for (int x = 0; x < width; ++x) {
                sb.append(" ");
                // Check for west wall
                if(cells[y][x].isBlocked(Direction.WEST)) {
                    sb.append(ANSI_RED + "|" + ANSI_BLACK);
                } else {
                    sb.append(" ");
                }
                // Check if robotrally.robot.Robot is in current cell
                if (cells[y][x].isOccupied()) {
                    String cell = cells[y][x].toString();
                    cell = cell.substring(cell.length() - 2);
                    sb.append(ANSI_BLUE + cell + ANSI_BLACK);
                } else {
                    sb.append(cells[y][x] + ANSI_BLACK);
                }
                // Check for east wall
                if(cells[y][x].isBlocked(Direction.EAST)) {
                    sb.append(ANSI_RED + "|" + ANSI_BLACK);
                } else {
                    sb.append(" ");
                }
                if (x == width - 1) {
                    sb.append(" ");
                } else {
                    sb.append("  ");
                }
            }
            sb.append("|\n");

            // Check for south wall
            sb.append("    |");
            for(int x = 0; x < width; ++x) {
                if(cells[y][x].isBlocked(Direction.SOUTH)) {
                    sb.append(ANSI_RED + "  __  " + ANSI_BLACK);
                } else {
                    sb.append("      ");
                }
                if(x < width - 1) {
                    sb.append(" ");
                }
            }
            sb.append("|\n");
        }
        // lower border
        sb.append("    ");
        for (int i = 0; i < width; ++i) {
            sb.append("+------");
        }
        sb.append("+");
        return sb.toString();
    }
}
