package robotrally.mapcells;

import javafx.scene.paint.Color;
import robotrally.robot.Robot;

public class Laser extends MapCell {
    private static final int DEFAULT_PRIORITY = 6;
    private final Direction direction;

    public Laser(Direction direction) {
        this.priority = DEFAULT_PRIORITY;
        this.direction = direction;
        setLaser(true);
        setWall(direction.getOpposite());
        this.color = Color.RED;
    }

    public Direction getDirection() {
        return this.direction;
    }

    public void activate(Robot robot) {
        System.err.println("Robot takes laser damage!");
        robot.takeDamage();
    }

    private void setWall(Direction direction) {
        switch(direction.toString()) {
            case "N":
                setNorthWall(true);
                break;
            case "S":
                setSouthWall(true);
                break;
            case "E":
                setEastWall(true);
                break;
            case "W":
                setWestWall(true);
        }
    }
}
