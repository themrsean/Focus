package robotrally.mapcells;

import javafx.scene.paint.Color;

public class Dock extends Repair {
    private static final int DEFAULT_PRIORITY = 10;
    private final int robotNumber;

    public Dock(int robot) {
        this.priority = DEFAULT_PRIORITY;
        this.robotNumber = robot;
        this.color = Color.GREEN;
    }

    public int getRobotNumber() {
        return robotNumber;
    }
}
