package robotrally.mapcells;

import javafx.scene.paint.Color;
import robotrally.robot.Robot;

public class Gear extends MapCell {
    private static final int DEFAULT_PRIORITY = 4;
    private final Rotation rotation;

    public Gear(Rotation rotation) {
        this.priority = DEFAULT_PRIORITY;
        this.rotation = rotation;
        this.color = Color.LIGHTSEAGREEN;
    }

    public Rotation getRotation() {
        return rotation;
    }

    public void activate(Robot robot) {
        if(rotation == Rotation.LEFT) {
            robot.setFacing(robot.getFacing().getLeft());
        } else {
            robot.setFacing(robot.getFacing().getRight());
        }
    }
}
