package robotrally.mapcells;

import javafx.scene.paint.Color;

public class ExpressConveyorBelt extends ConveyorBelt {
    private static final int DEFAULT_PRIORITY = 1;

    public ExpressConveyorBelt(Direction direction) {
        super(direction);
        this.priority = DEFAULT_PRIORITY;
        this.color = Color.VIOLET;
    }
}
