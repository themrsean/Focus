package robotrally.mapcells;

import javafx.scene.paint.Color;
import robotrally.robot.Robot;

public class Flag extends MapCell {
    private static final int DEFAULT_PRIORITY = 7;
    private final int number;

    public Flag(int number) {
        this.priority = DEFAULT_PRIORITY;
        this.number = number;
        this.color = Color.CYAN;
    }

    public int getNumber() {
        return number;
    }

    public void activate(Robot robot) {
        robot.setFlag(number);
    }
}
