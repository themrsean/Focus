package robotrally.mapcells;

import javafx.scene.control.Alert;
import javafx.scene.paint.Color;
import robotrally.robot.Robot;

public class Pit extends MapCell {
    private static final int DEFAULT_PRIORITY = 5;

    public Pit() {
        this.priority = DEFAULT_PRIORITY;
        this.color = Color.BLACK;
    }

    public void activate(Robot robot) {
        Alert alert = new Alert(Alert.AlertType.ERROR, "Robot fell into a pit!");
        alert.showAndWait();
        robot.removeLife();
        robot.setLocation(robot.getDock());
    }
}
