package robotrally.mapcells;

import javafx.scene.paint.Color;
import robotrally.robot.Robot;

@SuppressWarnings("ALL")
public abstract class MapCell implements Comparable<MapCell> {
    private static final int DEFAULT_PRIORITY = 100;

    protected int x = 0;
    protected int y = 0;
    protected boolean northWall = false;
    protected boolean southWall = false;
    protected boolean eastWall = false;
    protected boolean westWall = false;
    protected boolean occupied = false;
    protected boolean laser = false;
    protected Color color;
    protected int priority;

    public MapCell() {
        this.priority = DEFAULT_PRIORITY;
    }

    public MapCell(int x, int y) {
        this.priority = DEFAULT_PRIORITY;
        this.x = x;
        this.y = y;
        color = Color.GREY;
    }

    public int getPriority() {
        return this.priority;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public Color getColor() {
        return this.color;
    }

    public boolean hasLaser() {
        return laser;
    }

    public void setNorthWall(boolean northWall) {
        this.northWall = northWall;
    }

    public void setSouthWall(boolean southWall) {
        this.southWall = southWall;
    }

    public void setEastWall(boolean eastWall) {
        this.eastWall = eastWall;
    }

    public void setWestWall(boolean westWall) {
        this.westWall = westWall;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    public void setLaser(boolean laser) {
        this.laser = laser;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean isBlocked(Direction facing) {
        switch(facing) {
            case NORTH:
                return northWall;
            case SOUTH:
                return southWall;
            case EAST:
                return eastWall;
            default:
                return westWall;
        }
    }

    public abstract void activate(Robot robot);

    @Override
    public String toString() {
        return "--";
    }

    public int compareTo(MapCell o) {
        return this.priority - o.priority;
    }
}
