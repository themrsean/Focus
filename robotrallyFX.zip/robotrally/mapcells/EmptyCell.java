package robotrally.mapcells;

import javafx.scene.paint.Color;
import robotrally.robot.Robot;

public class EmptyCell extends MapCell {
    public EmptyCell() {
        super();
        color = Color.GREY;
    }

    public EmptyCell(int x, int y) {
        super(x, y);
        color = Color.GREY;
    }

    @Override
    public void activate(Robot robot) {
        // Empty cell. Nothing happens on activation.
    }
}
