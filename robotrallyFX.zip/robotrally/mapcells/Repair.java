package robotrally.mapcells;

import javafx.scene.paint.Color;
import robotrally.robot.Robot;

public class Repair extends MapCell {
    private static final int DEFAULT_PRIORITY = 10;

    public Repair() {
        this.priority = DEFAULT_PRIORITY;
        this.color = Color.GREEN;
    }

    public void activate(Robot robot) {
        robot.repair();
    }
}
