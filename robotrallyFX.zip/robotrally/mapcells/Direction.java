package robotrally.mapcells;

public enum Direction {
    NORTH(0, -1, "N"),
    SOUTH(0, 1, "S"),
    EAST(1, 0, "E"),
    WEST(-1, 0, "W");

    private int xDelta;
    private int yDelta;
    private String dir;
    private Direction opposite;
    private Direction left;
    private Direction right;

    static {
        NORTH.opposite = SOUTH;
        NORTH.left = WEST;
        NORTH.right = EAST;
        SOUTH.opposite = NORTH;
        SOUTH.left = EAST;
        SOUTH.right = WEST;
        EAST.opposite = WEST;
        EAST.left = NORTH;
        EAST.right = SOUTH;
        WEST.opposite = EAST;
        WEST.left = SOUTH;
        WEST.right = NORTH;
    }

    Direction(int x, int y, String dir) {
        xDelta = x;
        yDelta = y;
        this.dir = dir;

    }

    public int getxDelta() {
        return xDelta;
    }

    public int getyDelta() {
        return yDelta;
    }

    public Direction getOpposite() {
        return opposite;
    }

    public Direction getLeft() {
        return left;
    }

    public Direction getRight() {
        return right;
    }

    @Override
    public String toString() {
        return dir;
    }
}
