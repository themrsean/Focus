package robotrally.robot;

import robotrally.mapcells.Direction;
import robotrally.mapcells.Dock;
import robotrally.mapcells.MapCell;

public class Robot {
    private static final int STARTING_LIVES = 3;
    private static final int MAX_DAMAGE_POINTS = 10;
    private static final Direction STARTING_FACING = Direction.NORTH;

    private int lives;
    private int damagePoints;
    private final Dock dock;
    private Direction facing;
    private MapCell location;
    private final boolean[] flags;

    public Robot(Dock dock, int numFlags) {
        this.lives = STARTING_LIVES;
        this.damagePoints = MAX_DAMAGE_POINTS;
        this.dock = dock;
        this.location = dock;
        dock.setOccupied(true);
        facing = STARTING_FACING;
        flags = new boolean[numFlags];
    }

    // Getters and Setters
    public int getLives() {
        return lives;
    }

    public int getDamagePoints() {
        return damagePoints;
    }

    public MapCell getDock() {
        return dock;
    }

    public Direction getFacing() {
        return facing;
    }

    public MapCell getLocation() {
        return location;
    }

    public void setFacing(Direction facing) {
        this.facing = facing;
    }

    public void setLocation(MapCell location) {
        this.location = location;
    }

    // Actions
    public void turnLeft() {
        facing = facing.getLeft();
    }

    public void turnRight() {
        facing = facing.getRight();
    }

    public void setFlag(int flagNumber) {
        flags[flagNumber - 1] = true;
    }

    public void repair() {
        if(damagePoints < MAX_DAMAGE_POINTS) {
            ++damagePoints;
        }
    }

    public void fullRepair() {
        damagePoints = MAX_DAMAGE_POINTS;
    }

    public void takeDamage() {
        --damagePoints;
    }

    public void removeLife() {
        --lives;
    }

    public int flagsFound() {
        int total = 0;
        for(boolean found : flags) {
            if(found) {
                ++total;
            }
        }
        return total;
    }
}
