package robotrally;

import robotrally.mapcells.Direction;
import robotrally.mapcells.Dock;
import robotrally.mapcells.EmptyCell;
import robotrally.mapcells.ExpressConveyorBelt;
import robotrally.mapcells.Laser;
import robotrally.mapcells.MapCell;
import robotrally.robot.Robot;

import java.util.Arrays;
import java.util.PriorityQueue;

@SuppressWarnings("ALL")
public class Map {
    private final MapCell[][] cells;
    private final int width;
    private final int height;

    public Map(int width, int height) {
        this.width = width;
        this.height = height;
        cells = new MapCell[height][width];
    }

    public void addCell(MapCell cell, int width, int height) {
        cells[height][width] = cell;
    }

    public void initialize() {
        for (int x = 0; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
                cells[y][x] = new EmptyCell(x, y);
            }
        }
    }

    public MapCell getCell(int width, int height) {
        return cells[height][width];
    }

    public Dock getDock(int number) {
        for(MapCell[] row : cells) {
            for(MapCell m : row) {
                if(m instanceof Dock) {
                    if(((Dock) m).getRobotNumber() == number) {
                        return (Dock) m;
                    }
                }
            }
        }
        return null;
    }

    public void setLasers() {
        for(MapCell[] row : cells) {
            for (MapCell m : row) {
                if (m instanceof Laser) {
                    MapCell current = m;
                    Direction laserPointing = ((Laser) m).getDirection();
                    int x = current.getX() + laserPointing.getxDelta();
                    int y = current.getY() + laserPointing.getyDelta();
                    while(isOnMap(x, y) && !(current instanceof Laser &&
                            ((Laser)current).getDirection().getOpposite().equals(laserPointing))) {
                        current = getCell(x, y);
                        current.setLaser(true);
                        x = current.getX() + laserPointing.getxDelta();
                        y = current.getY() + laserPointing.getyDelta();
                    }
                }
            }
        }
    }

    public boolean isOnMap(int x, int y) {
        return x >= 0 && y >= 0 && x <= width - 1 && y <= height - 1;
    }

    public void activate(Robot robot) {
        PriorityQueue<MapCell> activationList = new PriorityQueue<>();
        for(MapCell[] row : cells) {
            activationList.addAll(Arrays.asList(row));
        }
        int priority = Integer.MAX_VALUE;
        while(!activationList.isEmpty()) {
            MapCell current = activationList.poll();
            if(current.isOccupied()) {
                if(current.getPriority() != priority) {
                    current.activate(robot);
                    priority = current.getPriority();
                    if (current instanceof ExpressConveyorBelt) {
                        current.activate(robot);
                    }
                }
            }
        }
    }
}
