package robotrally;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import robotrally.mapcells.*;
import robotrally.robot.Robot;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Controller implements Initializable {
    private static final int DEFAULT_WIDTH = 12;
    private static final int DEFAULT_HEIGHT = 16;
    private static final double SCALE = 30.0;
    @FXML
    private Label flagLabel;
    @FXML
    private Label damageLabel;
    @FXML
    private Label livesLabel;
    @FXML
    private Canvas canvas;

    private GraphicsContext gc;
    private Map map;
    private Robot robot;
    private File mapFile;
    private int numFlags;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        map = new Map(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        map.initialize();
        gc = canvas.getGraphicsContext2D();
    }

    /*
     * Implement the listener methods for robot movement. For each listener, you will need to:
     * 1) Perform the actual movement
     * 2) update the view so we can see the robot having moved
     * 3) activate the cell to see what happens to the poor robot
     * 4) Update the view again to show the results of the activation
     */
    @FXML
    private void turnLeft() {
        // TODO
    }

    @FXML
    private void forward() {
        // TODO
    }

    @FXML
    private void turnRight() {
        // TODO
    }

    @FXML
    private void openMap() {
        FileChooser chooser = new FileChooser();
        mapFile = chooser.showOpenDialog(null);
        if (mapFile != null) {
            readFile();
            drawMap();
        }
        robot = new Robot(map.getDock(1), numFlags);
        drawRobot();
    }

    @FXML
    private void quit() {
        Platform.exit();
    }

    private void readFile() {
        try {
            Scanner read = new Scanner(mapFile);
            numFlags = read.nextInt();
            read.nextLine();
            while (read.hasNextLine()) {
                MapCell cell = parseCell(read.nextLine());
                map.addCell(cell, cell.getX(), cell.getY());
            }
            map.setLasers();

        } catch (FileNotFoundException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Could not open file");
            alert.showAndWait();
        }
    }

    private MapCell parseCell(String line) {
        /*
         * x,y,type,N,S,E,W,SPECIAL
         * C -  Conveyor Belt - direction
         * EC - Express Conveyor Belt - direction
         * EM - Empty Cell
         * D -  Dock
         * F -  Flag
         * G -  Gear - rotation
         * L -  Laser - direction
         * P -  Pit
         * RP - Repair
         */
        MapCell cell;
        String[] split = line.split(",");
        // xy coordinates
        int x = Integer.parseInt(split[0]);
        int y = Integer.parseInt(split[1]);
        String type = split[2];

        switch (type) {
            case "C":
                Direction d = parseDirection(split[7]);
                cell = new ConveyorBelt(d);
                ((ConveyorBelt)cell).setController(this);
                break;
            case "EC":
                d = parseDirection(split[7]);
                cell = new ExpressConveyorBelt(d);
                ((ExpressConveyorBelt)cell).setController(this);
                break;
            case "D":
                int robot = Integer.parseInt(split[7]);
                cell = new Dock(robot);
                break;
            case "F":
                int number = Integer.parseInt((split[7]));
                cell = new Flag(number);
                break;
            case "G":
                Rotation rotate = parseRotation(split[7]);
                cell = new Gear(rotate);
                break;
            case "L":
                d = parseDirection(split[7]);
                cell = new Laser(d);
                break;
            case "P":
                cell = new Pit();
                break;
            case "RP":
                cell = new Repair();
                break;
            default:
                cell = new EmptyCell();
        }

        cell.setX(x);
        cell.setY(y);

        if (split[3].equals("Y")) {
            cell.setNorthWall(true);
        }
        if (split[4].equals("Y")) {
            cell.setSouthWall(true);
        }
        if (split[5].equals("Y")) {
            cell.setEastWall(true);
        }
        if (split[6].equals("Y")) {
            cell.setWestWall(true);
        }
        return cell;
    }

    private Direction parseDirection(String d) {
        switch (d) {
            case "N":
                return Direction.NORTH;
            case "S":
                return Direction.SOUTH;
            case "E":
                return Direction.EAST;
            default:
                return Direction.WEST;
        }
    }

    private Rotation parseRotation(String r) {
        if (r.equals("L")) {
            return Rotation.LEFT;
        } else {
            return Rotation.RIGHT;
        }
    }

    private void drawMap() {
        gc.setFont(Font.font(20));
        for (int y = 0; y < DEFAULT_HEIGHT; ++y) {
            for (int x = 0; x < DEFAULT_WIDTH; ++x) {
                MapCell cell = map.getCell(x, y);
                gc.setFill(cell.getColor());
                gc.fillRect(x * SCALE, y * SCALE, SCALE - 2, SCALE - 2);
                if (cell instanceof Dock) {
                    int number = ((Dock) cell).getRobotNumber();
                    gc.strokeText(number + "", x * SCALE + (SCALE / 4), y * SCALE + (SCALE / 1.5));
                } else if (cell instanceof Flag) {
                    int number = ((Flag) cell).getNumber();
                    double[] xPoints = {x * SCALE, x * SCALE + SCALE, x * SCALE};
                    double[] yPoints = {y * SCALE, y * SCALE + SCALE / 2, y * SCALE + SCALE};
                    gc.strokePolygon(xPoints, yPoints, 3);
                    gc.strokeText(number + "", x * SCALE, y * SCALE + (SCALE / 1.5));
                } else if (cell instanceof ConveyorBelt) {
                    Direction direction = ((ConveyorBelt) cell).getDirection();
                    gc.setFont(Font.font(30));
                    switch (direction) {
                        case NORTH:
                            gc.strokeText("⬆", x * SCALE + (SCALE / 4), y * SCALE + (SCALE / 1.5));
                            break;
                        case SOUTH:
                            gc.strokeText("⬇", x * SCALE + (SCALE / 4), y * SCALE + (SCALE / 1.5));
                            break;
                        case EAST:
                            gc.setFont(Font.font(20));
                            gc.strokeText("➡", x * SCALE + (SCALE / 4), y * SCALE + (SCALE / 1.5));
                            break;
                        default:
                            gc.setFont(Font.font(30));
                            gc.strokeText("⬅", x * SCALE + (SCALE / 4), y * SCALE + (SCALE / 1.5));
                            break;
                    }
                } else if (cell instanceof Gear) {
                    gc.setFont(Font.font(40));
                    if (((Gear) cell).getRotation().equals(Rotation.LEFT)) {
                        gc.strokeText("⟲", x * SCALE, y * SCALE + (SCALE / 1.2));
                    } else {
                        gc.strokeText("⟳", x * SCALE, y * SCALE + (SCALE / 1.2));
                    }
                } else if (cell instanceof Repair) {
                    gc.setFont(Font.font(40));
                    gc.strokeText("+", x * SCALE, y * SCALE + (SCALE / 1.2));
                }
                gc.setFont(Font.font(20));
                if (cell.hasLaser()) {
                    gc.setFill(Color.RED);
                    gc.fillRect(x * SCALE, y * SCALE, SCALE - 2, SCALE - 2);
                }
                gc.setLineWidth(4);
                if (cell.isBlocked(Direction.NORTH)) {

                    gc.setFill(Color.BLACK);
                    gc.strokeLine(x * SCALE, y * SCALE, x * SCALE + SCALE, y * SCALE);
                }
                if (cell.isBlocked(Direction.SOUTH)) {

                    gc.setFill(Color.BLACK);
                    gc.strokeLine(x * SCALE, y * SCALE + SCALE, x * SCALE + SCALE, y * SCALE + SCALE);
                }
                if (cell.isBlocked(Direction.EAST)) {
                    gc.setFill(Color.BLACK);
                    gc.strokeLine(x * SCALE + SCALE, y * SCALE, x * SCALE + SCALE, y * SCALE + SCALE);
                }
                if (cell.isBlocked(Direction.WEST)) {
                    gc.setFill(Color.BLACK);
                    gc.strokeLine(x * SCALE, y * SCALE, x * SCALE, y * SCALE + SCALE);
                }
                gc.setLineWidth(1);
            }
        }
    }

    private void drawRobot() {
        MapCell current = robot.getLocation();
        Direction direction = robot.getFacing();
        gc.setFill(Color.GOLD);
        gc.fillRect(current.getX() * SCALE, current.getY() * SCALE, SCALE - 2, SCALE - 2);
        gc.setFill(Color.BLACK);
        switch (direction) {
            case NORTH:
                gc.fillRect(current.getX() * SCALE + 4, current.getY() * SCALE, 5, 5);
                gc.fillRect(current.getX() * SCALE + 18, current.getY() * SCALE, 5, 5);
                break;
            case SOUTH:
                gc.fillRect(current.getX() * SCALE + 4, current.getY() * SCALE + 23, 5, 5);
                gc.fillRect(current.getX() * SCALE + 18, current.getY() * SCALE + 23, 5, 5);
                break;
            case EAST:
                gc.fillRect(current.getX() * SCALE + 23, current.getY() * SCALE + 4, 5, 5);
                gc.fillRect(current.getX() * SCALE + 23, current.getY() * SCALE + 18, 5, 5);
                break;
            default:
                gc.fillRect(current.getX() * SCALE, current.getY() * SCALE + 4, 5, 5);
                gc.fillRect(current.getX() * SCALE, current.getY() * SCALE + 18, 5, 5);
        }
    }

    private void update() {
        if(robot.getLives() == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Sorry, your robot didn't make it");
            alert.showAndWait();
            Platform.exit();
        }
        if(robot.getDamagePoints() == 0) {
            robot.setLocation(robot.getDock());
            robot.fullRepair();
            robot.removeLife();
            robot.setFacing(Direction.NORTH);
        }
        drawMap();
        drawRobot();
        flagLabel.setText("Flags: " + robot.flagsFound());
        damageLabel.setText("Damage: " + robot.getDamagePoints());
        livesLabel.setText("Lives: " + robot.getLives());
    }

    public void move() {
        MapCell current = robot.getLocation();
        Direction facing = robot.getFacing();
        if (!robot.getLocation().isBlocked(facing)) {
            int x = current.getX() + facing.getxDelta();
            int y = current.getY() + facing.getyDelta();
            if (map.isOnMap(x, y)) {
                robot.setLocation(map.getCell(x, y));
                map.getCell(x, y).setOccupied(true);
                current.setOccupied(false);
                update();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Robot fell off the edge!");
                alert.showAndWait();
                robot.removeLife();
                robot.setLocation(robot.getDock());
            }
        }

    }
}